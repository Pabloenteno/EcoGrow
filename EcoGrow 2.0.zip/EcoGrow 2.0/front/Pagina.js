document.addEventListener('DOMContentLoaded', function() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    
    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('active');
        mainContent.classList.toggle('shifted');
    });
});
document.addEventListener('DOMContentLoaded', () => {
            const loginButton = document.getElementById('login');
            loginButton.addEventListener('click', () => {
                window.location.href = './login.html';
            });
});
document.addEventListener('DOMContentLoaded', () => {
            const loginButton = document.getElementById('favoritos');
            loginButton.addEventListener('click', () => {
                window.location.href = './favoritos.html';
            });
});
document.addEventListener('DOMContentLoaded', () => {
            const loginButton = document.getElementById('progresso');
            loginButton.addEventListener('click', () => {
                window.location.href = './Progresso.html';
            });
});

const voltar = document.getElementById('voltar')

voltar.addEventListener('click',() => {
    window.location.href = './Pagina.html';

})


const visualizar = document.getElementById('visualizar')
const input = document.getElementById("senha");
const imgOlho = document.getElementById('imgOlho')

visualizar.addEventListener('click', ()=>{
     if (input.type === "password") {
        input.type = "text";
        imgOlho.src = "./icons/Invisible.svg"

   } else {
        input.type = "password";
         imgOlho.src = "./icons/Eye.svg"
   }

})











