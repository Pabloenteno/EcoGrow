const logar = document.getElementById('logar');

logar.addEventListener('click', async () => {
  const email = document.getElementById('email').value;
  const senha = document.getElementById('senha').value;
  const mensagem = document.getElementById('mensagem');

  if (!email || !senha) {
    mensagem.style.display = ''
  } else {
    mensagem.style.display = 'none'; 
  }

  const response = await fetch('http://localhost:3002/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, senha })
  });

  const result = await response.json();

  if (result.success) {
    alert("Login bem-sucedido!");
    window.location.href = "Pagina.html";
    
}
});
