const cadastro = document.getElementById('cadastrar');

cadastro.addEventListener('click', async () => {
  const nome = document.getElementById('nome').value;
  const email = document.getElementById('email').value;
  const senha = document.getElementById('senha').value;

  
  if (!nome || !email || !senha) {
    const mensagem = document.getElementById('mensagem')
    mensagem.style.display = ''
  }else{
     mensagem.style.display = 'none'
  }


  const response = await fetch('http://localhost:3002/cadastrar', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome, email, senha })
  });

  const result = await response.json();

  if (result.success) {
    alert("Cadastro bem-sucedido!");
    window.location.href = "Login.html";
  } 
});
