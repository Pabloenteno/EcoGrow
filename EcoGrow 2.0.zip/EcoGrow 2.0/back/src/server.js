const express = require('express');
const cors = require('cors');
const connection = require('./db_config');
const app = express();

app.use(cors());
app.use(express.json());

const port = 3002;

app.post('/cadastrar', (req, res) => {
    const { nome, senha, email } = req.body;

    if (!nome || !senha || !email) {
        return res.status(400).json({ success: false, message: 'Preencha todos os campos.' });
    }

    const query = 'INSERT INTO usuario (nome, senha, email, tipo) VALUES (?, ?, ?, ?);';
    const values = [nome, senha, email, 'usuario'];

    connection.query(query, values, (err, results) => {
        if (err) {
            console.error('Erro no banco:', err);
            return res.status(500).json({ success: false, message: 'Erro ao cadastrar usuário.' });
        }
        res.json({ success: true, message: 'Usuário cadastrado com sucesso!' });
    });
});

app.post('/login', (req, res) => {
  const { email, senha } = req.body;

  const query = 'SELECT * FROM usuario WHERE email = ? AND senha = ?';

  connection.query(query, [email, senha], (err, results) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Erro no servidor.' });
    }

    if (results.length > 0) {
      const usuario = results[0];
      res.json({
        success: true,
        message: 'Login bem-sucedido!',
        tipo: usuario.tipo,
        nome: usuario.nome
      });
    } else {
      res.json({ success: false, message: 'Usuário ou senha incorretos!' });
    }
  });
});


app.listen(port, () => console.log(`Servidor rodando na porta ${port}`));
